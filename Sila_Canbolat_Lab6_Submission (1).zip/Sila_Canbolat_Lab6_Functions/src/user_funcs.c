#include "user_funcs.h"
#include <math.h>  /* NAN */

/* x^n for n >= 0: simple multiplication loop */
double pow_pos(double x, int n)
{
    if (n < 0) return NAN;
    if (x == 0.0 && n == 0) return NAN; /* undefined 0^0 */

    double r = 1.0;
    for (int i = 0; i < n; ++i) {
        r *= x;
    }
    return r;
}

/* x^n for n >= 0: exponentiation by squaring */
double pow_fast(double x, int n)
{
    if (n < 0) return NAN;
    if (x == 0.0 && n == 0) return NAN;

    double base = x;
    double r = 1.0;
    int e = n;

    while (e > 0) {
        if (e & 1) {
            r *= base;
        }
        base *= base;
        e >>= 1;
    }
    return r;
}
