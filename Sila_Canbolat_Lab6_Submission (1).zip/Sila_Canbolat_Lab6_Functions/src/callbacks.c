#include "callbacks.h"

void do_three(int x, ActionInt a, ActionInt b, ActionInt c)
{
    if (a) a(x);
    if (b) b(x);
    if (c) c(x);
}
