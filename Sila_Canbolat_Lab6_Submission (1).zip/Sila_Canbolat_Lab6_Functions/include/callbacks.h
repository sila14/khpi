#ifndef CALLBACKS_H
#define CALLBACKS_H

/* Variant 03 (Lab 06_03)
 * do_three(x, a, b, c) calls three actions in sequence.
 * Safety: each callback pointer may be NULL (then skipped).
 */

typedef void (*ActionInt)(int);

void do_three(int x, ActionInt a, ActionInt b, ActionInt c);

#endif /* CALLBACKS_H */
