#ifndef USER_MACROS_H
#define USER_MACROS_H

/* Variant 03 (Lab 06_02)
 * A) ABS(x)          -> |x|
 * B) SAT_ADD_U8(x,y) -> x <- clamp(x+y, 0, 255)
 *
 * Hygiene:
 * - Fully parenthesize arguments/expressions.
 * - Use do { ... } while(0) for multi-statement macro.
 * - Avoid side effects inside macro arguments (do NOT pass i++).
 */

#define ABS(x) ( ((x) < 0) ? (-(x)) : (x) )

#define SAT_ADD_U8(x,y)                 \
do {                                   \
    int _s = (int)(x) + (int)(y);      \
    if (_s < 0) _s = 0;                \
    else if (_s > 255) _s = 255;       \
    (x) = _s;                          \
} while (0)

#endif /* USER_MACROS_H */
