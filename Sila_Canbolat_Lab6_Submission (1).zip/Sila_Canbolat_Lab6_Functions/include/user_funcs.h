#ifndef USER_FUNCS_H
#define USER_FUNCS_H

/* Variant 03 (Lab 06_01)
 * A) pow_pos(x,n)  - x^n for n >= 0 using a simple loop
 * B) pow_fast(x,n) - x^n for n >= 0 using square-and-multiply
 *
 * Notes:
 * - No arrays.
 * - If n < 0 or (x == 0 and n == 0), the function returns NAN.
 */

double pow_pos(double x, int n);
double pow_fast(double x, int n);

#endif /* USER_FUNCS_H */
