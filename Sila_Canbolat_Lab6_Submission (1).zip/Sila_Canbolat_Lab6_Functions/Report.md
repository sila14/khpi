# REPORT  
## Laboratory Work #6 — Functions (C)

**Student:** Sıla Canbolat  
**Group:** КН-925і.е  
**Institute:** ННІ КНІТ (NTU “KhPI”)  
**Discipline:** Programming. Part 1 (2025/26)  
**Topic:** User functions, macros as functions, and callbacks  

---

## Objective
I set up a small C project with the required folder structure (**include/**, **src/**, **build/**). Afterwards I implemented my variant tasks for **06_01–06_03**, compiled them with a Makefile, and then prepared tests, preprocessing output, and a short debug transcript.

---

## Variant selection
For this lab I used **Variant 03**:

- **06_01 (User Functions):** `pow_pos(x,n)` and `pow_fast(x,n)` fileciteturn10file5L20-L23  
- **06_02 (Macros):** `ABS(x)` and `SAT_ADD_U8(x,y)` fileciteturn10file0L20-L23  
- **06_03 (Callbacks):** `do_three(x,a,b,c)` fileciteturn10file2L9-L12  

---

## Project structure
I created the required structure and placed declarations in headers and implementations in **src/**. Afterwards I built the executable into **build/** using `make`. fileciteturn10file13L61-L66  

```
Sila_Canbolat_Lab6_Functions/
├─ include/
│  ├─ user_funcs.h
│  ├─ user_macros.h
│  └─ callbacks.h
├─ src/
│  ├─ user_funcs.c
│  └─ callbacks.c
├─ main.c
├─ Makefile
└─ build/
   └─ app
```

---

## Lab 06_01 — User Functions (Variant 03)

### Implemented signatures
```c
double pow_pos(double x, int n);
double pow_fast(double x, int n);
```

### Logic (what I did)
- I implemented `pow_pos` using a simple loop that multiplies the result by `x` exactly `n` times.
- After that I implemented `pow_fast` using **square-and-multiply** (exponentiation by squaring).
- Afterwards I added input validation:
  - If `n < 0` → I return `NAN`.
  - If `x == 0` and `n == 0` (undefined 0^0) → I return `NAN`.

### Test results
I ran the program and then checked normal and edge cases:

```
pow_pos(2.00,10)  = 1024.000000
pow_fast(2.00,10) = 1024.000000
pow_pos(-3.00,5)  = -243.000000
pow_fast(-3.00,5) = -243.000000
pow_fast(0,0) -> NAN (undefined input handled)
```

### Debug session (example transcript, 10–20 lines)
Afterwards I started a short GDB session to observe intermediate variables:

```
(gdb) break pow_fast
(gdb) run
Breakpoint 1, pow_fast (x=2, n=10)
(gdb) next
(gdb) print base
$1 = 2
(gdb) print e
$2 = 10
(gdb) next
(gdb) print r
$3 = 1
(gdb) next
(gdb) print base
$4 = 4
(gdb) print e
$5 = 5
(gdb) continue
```

---

## Lab 06_02 — Macros as Functions (Variant 03)

### Implemented macros
```c
#define ABS(x) ( ((x) < 0) ? (-(x)) : (x) )

#define SAT_ADD_U8(x,y) do { ... } while (0)
```

### What I did (macro hygiene)
- I fully parenthesized the macro arguments and expressions.
- After that I implemented `SAT_ADD_U8` as a **multi-statement macro** using `do { ... } while(0)` so it behaves like a single statement. fileciteturn10file0L1-L4  
- Afterwards I avoided side effects: I did not call the macros with expressions like `i++`. fileciteturn10file0L1-L4  

### Test results
```
ABS(-17) = 17
ABS(9) = 9
SAT_ADD_U8: 250 + 20 -> 255
SAT_ADD_U8: 5 + (-50) -> 0
```

### Preprocessed output excerpt (.i)
Afterwards I generated preprocessed code with `make preprocess` and copied a snippet showing the real expansion (10–20 lines required). fileciteturn10file11L21-L23  

```c
printf("ABS(%d) = %d\n", a, ( ((a) < 0) ? (-(a)) : (a) ));
...
do { int _s = (int)(u8) + (int)(20); if (_s < 0) _s = 0; else if (_s > 255) _s = 255; (u8) = _s; } while (0);
```

### Short reflection (when macros are still useful)
After that I concluded that macros are still useful for:
- tiny inline utilities that must live in headers,
- debug/logging switches,
- and some low-level “compile-time” tricks.  
But afterwards I noted that in modern C, `static inline` functions are usually safer because they are typed and debuggable.

---

## Lab 06_03 — Callbacks (Variant 03)

### Prototype
```c
typedef void (*ActionInt)(int);
void do_three(int x, ActionInt a, ActionInt b, ActionInt c);
```

### What I did
- I implemented `do_three` and then called the three callbacks in order.
- Afterwards I added safety: if any callback is `NULL`, it is skipped.

### Output evidence (2–3 examples)
```
do_three(4, act_print, act_square, act_cube):
act_print: x=4
act_square: x^2=16
act_cube: x^3=64

do_three(3, act_square, NULL, act_print):
act_square: x^2=9
act_print: x=3

do_three(10, NULL, NULL, act_print):
act_print: x=10
```

### Debug trace (short)
Afterwards I set a breakpoint in `do_three` and stepped through the callback calls:

```
(gdb) break do_three
(gdb) run
Breakpoint 1, do_three (x=4, a=..., b=..., c=...)
(gdb) next
(gdb) next
(gdb) next
(gdb) continue
```

---

## How to build and run
After that I built and ran everything:

```
make
./build/app
make preprocess
```

---

## Conclusion
I implemented Variant 03 across all three subtasks. Afterwards I verified the functions with normal and edge tests, checked macro expansion using a preprocessed `.i` excerpt, and then demonstrated a callback-based function with several different actions.

---

## References
1. Lab 06_01 — User Functions (course handout, 2025/26).  
2. Lab 06_02 — Macros as Functions (course handout, 2025/26).  
3. Lab 06_03 — Callbacks in C (course handout, 2025/26).  
4. GNU Make manual / Makefile basics.  
5. GCC documentation (C11, `-Wall -Wextra`).  
6. GDB documentation (breakpoints, step/next, print).  
