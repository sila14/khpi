#include <stdio.h>
#include <math.h>

#include "user_funcs.h"
#include "user_macros.h"
#include "callbacks.h"

/* --- callbacks for Lab 06_03 (Variant 03) --- */
static void act_print(int x)      { printf("act_print: x=%d\n", x); }
static void act_square(int x)     { printf("act_square: x^2=%d\n", x * x); }
static void act_cube(int x)       { printf("act_cube: x^3=%d\n", x * x * x); }

int main(void)
{
    /* ---------------- Lab 06_01: User Functions (Variant 03) ---------------- */
    puts("=== Lab 06_01: User Functions (Variant 03) ===");

    double x1 = 2.0; int n1 = 10;
    double x2 = -3.0; int n2 = 5;
    double x3 = 0.0; int n3 = 0; /* edge: undefined 0^0 */

    double r1a = pow_pos(x1, n1);
    double r1b = pow_fast(x1, n1);
    printf("pow_pos(%.2f,%d)  = %.6f\n", x1, n1, r1a);
    printf("pow_fast(%.2f,%d) = %.6f\n", x1, n1, r1b);

    double r2a = pow_pos(x2, n2);
    double r2b = pow_fast(x2, n2);
    printf("pow_pos(%.2f,%d)  = %.6f\n", x2, n2, r2a);
    printf("pow_fast(%.2f,%d) = %.6f\n", x2, n2, r2b);

    double r3 = pow_fast(x3, n3);
    if (isnan(r3)) {
        puts("pow_fast(0,0) -> NAN (undefined input handled)");
    }

    /* ---------------- Lab 06_02: Macros as Functions (Variant 03) ---------------- */
    puts("\n=== Lab 06_02: Macros as Functions (Variant 03) ===");

    int a = -17;
    int b = 9;
    printf("ABS(%d) = %d\n", a, ABS(a));
    printf("ABS(%d) = %d\n", b, ABS(b));

    int u8 = 250;
    SAT_ADD_U8(u8, 20);
    printf("SAT_ADD_U8: 250 + 20 -> %d\n", u8);

    u8 = 5;
    SAT_ADD_U8(u8, -50);
    printf("SAT_ADD_U8: 5 + (-50) -> %d\n", u8);

    /* ---------------- Lab 06_03: Callbacks (Variant 03) ---------------- */
    puts("\n=== Lab 06_03: Callbacks (Variant 03) ===");
    puts("do_three(4, act_print, act_square, act_cube):");
    do_three(4, act_print, act_square, act_cube);

    puts("\ndo_three(3, act_square, NULL, act_print):");
    do_three(3, act_square, NULL, act_print);

    puts("\ndo_three(10, NULL, NULL, act_print):");
    do_three(10, NULL, NULL, act_print);

    return 0;
}
