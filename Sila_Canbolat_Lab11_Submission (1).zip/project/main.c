// Lab Work #11 - Recursion (Variant 3)
// Student: Sila Canbolat, group KN-925i.e
// Task A: Find GCD of two numbers using recursion (+ iterative version for comparison).
// Task B: Draw a diamond of stars with height (2*n - 1) using recursion.
//
// Build: make
// Run:   ./build/app

#include <stdio.h>
#include <time.h>

static int iabs_int(int x) { return (x < 0) ? -x : x; }

/* ---------- Task A: GCD (Euclid) ---------- */
int gcd_recursive(int a, int b)
{
    a = iabs_int(a);
    b = iabs_int(b);

    /* Base case */
    if (b == 0) return a;

    /* Recursive call reduces the problem: (a, b) -> (b, a mod b) */
    return gcd_recursive(b, a % b);
}

int gcd_iterative(int a, int b)
{
    a = iabs_int(a);
    b = iabs_int(b);

    while (b != 0)
    {
        int r = a % b;
        a = b;
        b = r;
    }
    return a;
}

/* A tiny CPU-time benchmark using clock().
   We run the same operation many times so the difference becomes measurable. */
double benchmark_gcd(int (*gcd_fn)(int, int), int a, int b, long long reps)
{
    clock_t t0 = clock();
    volatile int sink = 0; /* prevents optimizing the calls away */

    for (long long i = 0; i < reps; ++i)
    {
        sink ^= gcd_fn(a, b);
        /* small deterministic change to inputs */
        a += 1;
        b += 2;
        if (b == 0) b = 1;
    }

    clock_t t1 = clock();
    (void)sink;
    return (double)(t1 - t0) / (double)CLOCKS_PER_SEC;
}

/* ---------- Task B: Recursive symbol drawing (diamond) ---------- */
void print_chars(char ch, int count)
{
    if (count <= 0) return;
    putchar(ch);
    print_chars(ch, count - 1);
}

void draw_row(int row, int n)
{
    /* row in [1..n] for top; symmetric for bottom.
       spaces: n - row
       stars : 2*row - 1 */
    int spaces = n - row;
    int stars  = 2 * row - 1;

    print_chars(' ', spaces);
    print_chars('*', stars);
    putchar('\n');
}

void draw_upper(int row, int n)
{
    if (row > n) return;
    draw_row(row, n);
    draw_upper(row + 1, n);
}

void draw_lower(int row, int n)
{
    if (row < 1) return;
    draw_row(row, n);
    draw_lower(row - 1, n);
}

void draw_diamond(int n)
{
    if (n <= 0) return;
    draw_upper(1, n);
    draw_lower(n - 1, n);
}

int main(void)
{
    int a, b, n;

    printf("Enter two integers a and b for GCD: ");
    if (scanf("%d %d", &a, &b) != 2)
    {
        puts("Input error.");
        return 1;
    }

    printf("Enter n for diamond (n > 0): ");
    if (scanf("%d", &n) != 1)
    {
        puts("Input error.");
        return 1;
    }
    if (n <= 0)
    {
        puts("Error: n must be positive.");
        return 2;
    }

    int g_rec = gcd_recursive(a, b);
    int g_it  = gcd_iterative(a, b);

    printf("\nResult:\n");
    printf("GCD recursive: %d\n", g_rec);
    printf("GCD iterative: %d\n", g_it);

    puts("\nDiamond:");
    draw_diamond(n);

    /* Additional task: compare execution time */
    const long long reps = 2000000; /* 2 million */
    double t_rec = benchmark_gcd(gcd_recursive, a, (b == 0 ? 1 : b), reps);
    double t_it  = benchmark_gcd(gcd_iterative, a, (b == 0 ? 1 : b), reps);

    printf("\nBenchmark (CPU time using clock(), %lld repetitions):\n", reps);
    printf("Recursive: %.6f s\n", t_rec);
    printf("Iterative: %.6f s\n", t_it);

    puts("\nTip: You can also measure wall time in Linux with `time ./build/app`");
    puts("     or in Windows PowerShell with `Measure-Command { start-process .\\build\\app.exe -Wait }`.");

    return 0;
}
