#ifndef MAT8_H
#define MAT8_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* -------- Lab 8.2 (2D arrays), Variant 03 -------- */

/* Group 1, Task 7:
   Minimum in the lower triangle (below the main diagonal).
   Matrix must be square: rows == cols, and size >= 2.
   Returns 1 on success, 0 on invalid input. */
int mat_min_lower_triangle(const int *m, size_t rows, size_t cols, int *out_min);

/* Group 2, Task 4:
   Sum of each row. out_sums must have length rows.
   Returns 1 on success, 0 on invalid input. */
int mat_row_sums(const int *m, size_t rows, size_t cols, long long *out_sums);

/* Group 3, Task 2:
   Minimum element of the matrix.
   Returns 1 on success, 0 on invalid input. */
int mat_min_element(const int *m, size_t rows, size_t cols, int *out_min);

/* Group 4, Task 18:
   Flatten matrix into 1D and compute sum of squared differences from the mean:
     SSD = sum_i (x_i - mean)^2
   Returns 1 on success, 0 on invalid input. */
int mat_sum_squared_diffs_mean(const int *m, size_t rows, size_t cols, double *out_ssd);

/* Utility used in demo/tests */
void mat_print(const int *m, size_t rows, size_t cols);

#ifdef __cplusplus
}
#endif
#endif /* MAT8_H */
