#ifndef ARR8_H
#define ARR8_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* -------- Lab 8.1 (1D arrays), Variant 03 -------- */

/* Group 1: find minimum and maximum of an array.
   Returns 1 on success, 0 on invalid input. */
int arr_min_max(const int *a, size_t n, int *out_min, int *out_max);

/* Group 2: find the largest element (same value as max, but separate task).
   Returns 1 on success, 0 on invalid input. */
int arr_largest(const int *a, size_t n, int *out_max);

/* Group 3: replace negative values with zeros (in place). */
void arr_replace_negative_with_zero(int *a, size_t n);

/* Group 4: insertion sort (ascending, in place). */
void arr_insertion_sort(int *a, size_t n);

/* Group 5: mode of the array (most frequent element).
   If there are multiple modes, the smallest value is returned.
   Returns 1 on success, 0 on invalid input. */
int arr_mode(const int *a, size_t n, int *out_mode);

/* Utility used in demo/tests */
void arr_print(const int *a, size_t n);

#ifdef __cplusplus
}
#endif
#endif /* ARR8_H */
