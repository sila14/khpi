# Lab Work #8 — Arrays and Matrices (C)

**Student:** Sıla Canbolat  
**Group:** КН-925і.е (ННІ КНІТ)  
**Variant:** 03  

## 1. Objective
In this lab I practiced working with **one-dimensional arrays** and **2D arrays (matrices)** in C. I implemented the required operations as separate functions and then I verified them with unit tests.

## 2. Variant 03 tasks

### 2.1 Lab 8.1 (1D arrays)
For Variant 03 I implemented one task from each group:
- Group 1: Minimum and maximum
- Group 2: Find the largest element
- Group 3: Replace negative values with zeros
- Group 4: Insertion sort
- Group 5: Mode of the array

### 2.2 Lab 8.2 (2D arrays / matrices)
For Variant 03 the table assigns:
- Group 1 — Task 7: Minimum below main diagonal
- Group 2 — Task 4: Sum of each row
- Group 3 — Task 2: Minimum element of the matrix
- Group 4 — Task 18: Sum of squared differences (using 1D representation)

## 3. What I did (implementation)
- I created a small C library with two modules: `arr8` and `mat8`.
- Afterwards, I implemented each task as a separate function with input validation.
- After that, I added a tiny test runner (`tests/`) and wrote unit tests for every function.
- Finally, I built and ran the demo and tests through the Makefile.

### 3.1 Definition used for “sum of squared differences”
I used this clear definition:

SSD = sum_i (x_i - mean)^2, where mean is the average of all elements.

## 4. Build & run

```bash
make            # builds build/app
./build/app     # demo (random values)

make test       # builds + runs unit tests
```

## 5. Conclusion
I learned how to implement reusable array/matrix functions, apply index-based logic, and verify correctness using unit tests.

## References
- arrays_eng.pdf (Lab Work #8.1)
- matrix.pdf (Lab Work #8.2)
