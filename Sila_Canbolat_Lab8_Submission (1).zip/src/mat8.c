#include "mat8.h"
#include <stdio.h>

static size_t idx(size_t r, size_t c, size_t cols) { return r * cols + c; }

int mat_min_lower_triangle(const int *m, size_t rows, size_t cols, int *out_min)
{
    if (!m || !out_min) return 0;
    if (rows == 0 || cols == 0) return 0;
    if (rows != cols) return 0;
    if (rows < 2) return 0;

    int mn = m[idx(1, 0, cols)];

    for (size_t r = 1; r < rows; ++r) {
        for (size_t c = 0; c < r; ++c) {
            int v = m[idx(r, c, cols)];
            if (v < mn) mn = v;
        }
    }

    *out_min = mn;
    return 1;
}

int mat_row_sums(const int *m, size_t rows, size_t cols, long long *out_sums)
{
    if (!m || !out_sums) return 0;
    if (rows == 0 || cols == 0) return 0;

    for (size_t r = 0; r < rows; ++r) {
        long long s = 0;
        for (size_t c = 0; c < cols; ++c) {
            s += m[idx(r, c, cols)];
        }
        out_sums[r] = s;
    }
    return 1;
}

int mat_min_element(const int *m, size_t rows, size_t cols, int *out_min)
{
    if (!m || !out_min) return 0;
    if (rows == 0 || cols == 0) return 0;

    int mn = m[0];
    for (size_t i = 1; i < rows * cols; ++i) {
        if (m[i] < mn) mn = m[i];
    }
    *out_min = mn;
    return 1;
}

int mat_sum_squared_diffs_mean(const int *m, size_t rows, size_t cols, double *out_ssd)
{
    if (!m || !out_ssd) return 0;
    if (rows == 0 || cols == 0) return 0;

    const size_t n = rows * cols;

    double sum = 0.0;
    for (size_t i = 0; i < n; ++i) sum += (double)m[i];
    const double mean = sum / (double)n;

    double ssd = 0.0;
    for (size_t i = 0; i < n; ++i) {
        const double d = (double)m[i] - mean;
        ssd += d * d;
    }

    *out_ssd = ssd;
    return 1;
}

void mat_print(const int *m, size_t rows, size_t cols)
{
    if (!m) return;
    for (size_t r = 0; r < rows; ++r) {
        printf("| ");
        for (size_t c = 0; c < cols; ++c) {
            printf("%4d ", m[idx(r, c, cols)]);
        }
        printf("|\n");
    }
}
