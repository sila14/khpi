#include "arr8.h"
#include <stdio.h>

int arr_min_max(const int *a, size_t n, int *out_min, int *out_max)
{
    if (!a || n == 0 || !out_min || !out_max) return 0;

    int mn = a[0];
    int mx = a[0];

    for (size_t i = 1; i < n; ++i) {
        if (a[i] < mn) mn = a[i];
        if (a[i] > mx) mx = a[i];
    }

    *out_min = mn;
    *out_max = mx;
    return 1;
}

int arr_largest(const int *a, size_t n, int *out_max)
{
    if (!a || n == 0 || !out_max) return 0;

    int mx = a[0];
    for (size_t i = 1; i < n; ++i) {
        if (a[i] > mx) mx = a[i];
    }
    *out_max = mx;
    return 1;
}

void arr_replace_negative_with_zero(int *a, size_t n)
{
    if (!a) return;
    for (size_t i = 0; i < n; ++i) {
        if (a[i] < 0) a[i] = 0;
    }
}

void arr_insertion_sort(int *a, size_t n)
{
    if (!a) return;

    for (size_t i = 1; i < n; ++i) {
        int key = a[i];
        size_t j = i;
        while (j > 0 && a[j - 1] > key) {
            a[j] = a[j - 1];
            --j;
        }
        a[j] = key;
    }
}

int arr_mode(const int *a, size_t n, int *out_mode)
{
    if (!a || n == 0 || !out_mode) return 0;

    int best_val = a[0];
    size_t best_count = 1;

    for (size_t i = 0; i < n; ++i) {
        size_t count = 1;
        for (size_t j = i + 1; j < n; ++j) {
            if (a[j] == a[i]) ++count;
        }
        if (count > best_count) {
            best_count = count;
            best_val = a[i];
        } else if (count == best_count && a[i] < best_val) {
            best_val = a[i];
        }
    }

    *out_mode = best_val;
    return 1;
}

void arr_print(const int *a, size_t n)
{
    putchar('[');
    for (size_t i = 0; i < n; ++i) {
        printf("%d", a[i]);
        if (i + 1 < n) printf(", ");
    }
    putchar(']');
}
