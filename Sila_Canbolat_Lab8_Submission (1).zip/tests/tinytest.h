#ifndef TINYTEST_H
#define TINYTEST_H

#include <stdio.h>
#include <math.h>

/* Counters are defined once in tests_main.c */
extern int tt_total;
extern int tt_failed;

#define TT_ASSERT_TRUE(expr) do { \
    ++tt_total; \
    if (!(expr)) { \
        ++tt_failed; \
        printf("FAIL:%s:%d: %s\n", __FILE__, __LINE__, #expr); \
    } \
} while(0)

#define TT_ASSERT_EQ_INT(exp, act) do { \
    ++tt_total; \
    if ((exp) != (act)) { \
        ++tt_failed; \
        printf("FAIL:%s:%d: expected %d, got %d\n", __FILE__, __LINE__, (int)(exp), (int)(act)); \
    } \
} while(0)

#define TT_ASSERT_EQ_LL(exp, act) do { \
    ++tt_total; \
    if ((exp) != (act)) { \
        ++tt_failed; \
        printf("FAIL:%s:%d: expected %lld, got %lld\n", __FILE__, __LINE__, (long long)(exp), (long long)(act)); \
    } \
} while(0)

#define TT_ASSERT_NEAR_DBL(exp, act, eps) do { \
    ++tt_total; \
    double _e = (double)(exp); \
    double _a = (double)(act); \
    if (fabs(_e - _a) > (double)(eps)) { \
        ++tt_failed; \
        printf("FAIL:%s:%d: expected %.10g, got %.10g (eps %.3g)\n", __FILE__, __LINE__, _e, _a, (double)(eps)); \
    } \
} while(0)

static inline int tt_summary(void)
{
    printf("\n[tests] total=%d failed=%d\n", tt_total, tt_failed);
    return tt_failed == 0 ? 0 : 1;
}

#endif /* TINYTEST_H */
