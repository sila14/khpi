#include "tinytest.h"
#include "arr8.h"

static void test_min_max(void)
{
    int a[] = {3, -2, 9, 9, 1};
    int mn = 0, mx = 0;
    TT_ASSERT_TRUE(arr_min_max(a, 5, &mn, &mx));
    TT_ASSERT_EQ_INT(-2, mn);
    TT_ASSERT_EQ_INT(9, mx);
}

static void test_largest(void)
{
    int a[] = {-5, -1, -9};
    int mx = 0;
    TT_ASSERT_TRUE(arr_largest(a, 3, &mx));
    TT_ASSERT_EQ_INT(-1, mx);
}

static void test_replace_negative(void)
{
    int a[] = {-3, 0, 2, -1};
    arr_replace_negative_with_zero(a, 4);
    TT_ASSERT_EQ_INT(0, a[0]);
    TT_ASSERT_EQ_INT(0, a[1]);
    TT_ASSERT_EQ_INT(2, a[2]);
    TT_ASSERT_EQ_INT(0, a[3]);
}

static void test_insertion_sort(void)
{
    int a[] = {5, 2, 2, -1, 9};
    arr_insertion_sort(a, 5);
    TT_ASSERT_EQ_INT(-1, a[0]);
    TT_ASSERT_EQ_INT(2, a[1]);
    TT_ASSERT_EQ_INT(2, a[2]);
    TT_ASSERT_EQ_INT(5, a[3]);
    TT_ASSERT_EQ_INT(9, a[4]);
}

static void test_mode_tie_break(void)
{
    int a[] = {7, 1, 7, 1, 2};
    int mode = 0;
    TT_ASSERT_TRUE(arr_mode(a, 5, &mode));
    TT_ASSERT_EQ_INT(1, mode);
}

void run_arr_tests(void)
{
    test_min_max();
    test_largest();
    test_replace_negative();
    test_insertion_sort();
    test_mode_tie_break();
}
