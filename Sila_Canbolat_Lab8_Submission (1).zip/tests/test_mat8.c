#include "tinytest.h"
#include "mat8.h"

void run_mat_tests(void)
{
    int m[] = {
        1,  2,  3,
        4, -5,  6,
        7,  8,  9
    };

    int mn_lower = 0;
    TT_ASSERT_TRUE(mat_min_lower_triangle(m, 3, 3, &mn_lower));
    TT_ASSERT_EQ_INT(4, mn_lower);

    long long sums[3] = {0,0,0};
    TT_ASSERT_TRUE(mat_row_sums(m, 3, 3, sums));
    TT_ASSERT_EQ_LL(6, sums[0]);
    TT_ASSERT_EQ_LL(5, sums[1]);
    TT_ASSERT_EQ_LL(24, sums[2]);

    int mn_all = 0;
    TT_ASSERT_TRUE(mat_min_element(m, 3, 3, &mn_all));
    TT_ASSERT_EQ_INT(-5, mn_all);

    double ssd = 0.0;
    TT_ASSERT_TRUE(mat_sum_squared_diffs_mean(m, 3, 3, &ssd));
    /* mean=35/9=3.888..., SSD = 148.888... */
    TT_ASSERT_NEAR_DBL(148.8888889, ssd, 1e-6);
}
