#include "tinytest.h"

/* define counters */
int tt_total = 0;
int tt_failed = 0;

void run_arr_tests(void);
void run_mat_tests(void);

int main(void)
{
    run_arr_tests();
    run_mat_tests();
    return tt_summary();
}
