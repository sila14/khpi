#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "arr8.h"
#include "mat8.h"

static int rand_int(int lo, int hi)
{
    return lo + (rand() % (hi - lo + 1));
}

int main(void)
{
    srand((unsigned)time(NULL));

    const size_t n = 12;
    int a[12];

    for (size_t i = 0; i < n; ++i) a[i] = rand_int(-9, 9);

    printf("1D array:\n");
    arr_print(a, n);
    printf("\n");

    int mn = 0, mx = 0;
    if (arr_min_max(a, n, &mn, &mx)) {
        printf("I did compute min and max: min=%d, max=%d\n", mn, mx);
    }

    int largest = 0;
    if (arr_largest(a, n, &largest)) {
        printf("Afterwards, I found the largest element: %d\n", largest);
    }

    printf("After that, I replaced negative values with zeros:\n");
    arr_replace_negative_with_zero(a, n);
    arr_print(a, n);
    printf("\n");

    printf("After that, I sorted the array using insertion sort:\n");
    arr_insertion_sort(a, n);
    arr_print(a, n);
    printf("\n");

    int mode = 0;
    if (arr_mode(a, n, &mode)) {
        printf("Finally, I computed the mode: %d\n", mode);
    }

    const size_t rows = 4, cols = 4;
    int m[16];

    for (size_t i = 0; i < rows * cols; ++i) m[i] = rand_int(-5, 9);

    printf("\nMatrix %zux%zu:\n", rows, cols);
    mat_print(m, rows, cols);

    int mn_low = 0;
    if (mat_min_lower_triangle(m, rows, cols, &mn_low)) {
        printf("I did compute min below main diagonal: %d\n", mn_low);
    }

    long long sums[4] = {0,0,0,0};
    if (mat_row_sums(m, rows, cols, sums)) {
        printf("Afterwards, I computed row sums: ");
        for (size_t r = 0; r < rows; ++r) {
            printf("%lld", sums[r]);
            if (r + 1 < rows) printf(", ");
        }
        printf("\n");
    }

    int mn_all = 0;
    if (mat_min_element(m, rows, cols, &mn_all)) {
        printf("After that, I found the minimum element in the matrix: %d\n", mn_all);
    }

    double ssd = 0.0;
    if (mat_sum_squared_diffs_mean(m, rows, cols, &ssd)) {
        printf("Finally, I computed sum of squared diffs from mean: %.6f\n", ssd);
    }

    return 0;
}
