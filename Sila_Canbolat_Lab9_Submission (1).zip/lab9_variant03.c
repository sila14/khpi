/*
 * Lab Work #9: Structs in C (Variant 3 — Hospital Patient Record)
 * Student: Sıla Canbolat (КН-925і.е, ННІ КНІТ)
 *
 * This program demonstrates nested structs and basic CRUD operations
 * (add/modify/delete/display) for a patient record.
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_STR 64
#define MAX_DESC 128
#define MAX_DATE 16
#define MAX_TREATMENTS 32

typedef struct {
    char name[MAX_STR];
    char specialty[MAX_STR];
    int room;
} Doctor;

typedef struct {
    char date[MAX_DATE];          /* YYYY-MM-DD */
    char description[MAX_DESC];
    double cost;
} Treatment;

typedef struct {
    int id;
    char fullName[MAX_STR];
    int age;

    Doctor doctor;
    int hasDoctor;

    Treatment treatments[MAX_TREATMENTS];
    int treatmentCount;
} Patient;

/* ---------- small helpers (safe input) ---------- */

static void trim_newline(char *s) {
    if (!s) return;
    size_t n = strlen(s);
    if (n > 0 && s[n - 1] == '\n') s[n - 1] = '\0';
}

static void flush_stdin(void) {
    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF) { /* discard */ }
}

static int read_line(const char *prompt, char *buf, size_t cap) {
    if (!buf || cap == 0) return 0;
    printf("%s", prompt);
    if (!fgets(buf, (int)cap, stdin)) return 0;
    trim_newline(buf);
    return 1;
}

static int read_int(const char *prompt, int *out) {
    if (!out) return 0;
    printf("%s", prompt);
    if (scanf("%d", out) != 1) {
        flush_stdin();
        return 0;
    }
    flush_stdin();
    return 1;
}

static int read_double(const char *prompt, double *out) {
    if (!out) return 0;
    printf("%s", prompt);
    if (scanf("%lf", out) != 1) {
        flush_stdin();
        return 0;
    }
    flush_stdin();
    return 1;
}

/* Basic format check: YYYY-MM-DD with digits and '-' */
static int is_valid_date_yyyy_mm_dd(const char *s) {
    if (!s) return 0;
    if (strlen(s) != 10) return 0;
    for (int i = 0; i < 10; ++i) {
        if (i == 4 || i == 7) {
            if (s[i] != '-') return 0;
        } else {
            if (!isdigit((unsigned char)s[i])) return 0;
        }
    }
    return 1;
}

static int is_blank(const char *s) {
    if (!s) return 1;
    while (*s) {
        if (!isspace((unsigned char)*s)) return 0;
        ++s;
    }
    return 1;
}

/* ---------- required functions for the variant ---------- */

void initPatient(Patient *p, int id, const char *name, int age) {
    if (!p) return;
    p->id = id;
    strncpy(p->fullName, name ? name : "Unknown", MAX_STR - 1);
    p->fullName[MAX_STR - 1] = '\0';
    p->age = age;
    p->hasDoctor = 0;
    p->treatmentCount = 0;
    memset(&p->doctor, 0, sizeof(p->doctor));
}

/* assignDoctor(Patient*, Doctor): Assigns a doctor to the patient. */
int assignDoctor(Patient *p, Doctor d) {
    if (!p) return 0;

    if (is_blank(d.name) || is_blank(d.specialty) || d.room <= 0) {
        return 0; /* invalid doctor data */
    }

    p->doctor = d;
    p->hasDoctor = 1;
    return 1;
}

/* addTreatment(Patient*, Treatment): Adds a treatment record. */
int addTreatment(Patient *p, Treatment t) {
    if (!p) return 0;

    if (p->treatmentCount >= MAX_TREATMENTS) return 0;
    if (!is_valid_date_yyyy_mm_dd(t.date)) return 0;
    if (is_blank(t.description)) return 0;
    if (t.cost < 0.0) return 0;

    p->treatments[p->treatmentCount++] = t;
    return 1;
}

/* getPatientSummary(Patient*): Generates a summary of the patient’s medical history. */
void printPatientSummary(const Patient *p) {
    if (!p) return;

    printf("\n=== PATIENT SUMMARY ===\n");
    printf("ID: %d\n", p->id);
    printf("Name: %s\n", p->fullName);
    printf("Age: %d\n", p->age);

    if (p->hasDoctor) {
        printf("Doctor: %s (%s), room %d\n", p->doctor.name, p->doctor.specialty, p->doctor.room);
    } else {
        printf("Doctor: [not assigned]\n");
    }

    printf("Treatments: %d\n", p->treatmentCount);
    double total = 0.0;
    for (int i = 0; i < p->treatmentCount; ++i) {
        total += p->treatments[i].cost;
    }
    printf("Total cost: %.2f\n", total);

    if (p->treatmentCount > 0) {
        printf("\nLast treatment:\n");
        Treatment last = p->treatments[p->treatmentCount - 1];
        printf("- %s | %s | cost %.2f\n", last.date, last.description, last.cost);
    }
    printf("=======================\n\n");
}

/* ---------- additional CRUD functions ---------- */

void displayPatient(const Patient *p) {
    if (!p) return;

    printf("\n--- Patient Record ---\n");
    printf("ID: %d\n", p->id);
    printf("Full name: %s\n", p->fullName);
    printf("Age: %d\n", p->age);

    if (p->hasDoctor) {
        printf("Doctor: %s | %s | room %d\n", p->doctor.name, p->doctor.specialty, p->doctor.room);
    } else {
        printf("Doctor: [not assigned]\n");
    }

    printf("\nTreatments (%d/%d):\n", p->treatmentCount, MAX_TREATMENTS);
    if (p->treatmentCount == 0) {
        printf("  (none)\n");
    } else {
        for (int i = 0; i < p->treatmentCount; ++i) {
            printf("  #%d: %s | %s | %.2f\n",
                   i, p->treatments[i].date, p->treatments[i].description, p->treatments[i].cost);
        }
    }
    printf("----------------------\n\n");
}

int modifyTreatment(Patient *p, int index, Treatment t) {
    if (!p) return 0;
    if (index < 0 || index >= p->treatmentCount) return 0;
    if (!is_valid_date_yyyy_mm_dd(t.date)) return 0;
    if (is_blank(t.description)) return 0;
    if (t.cost < 0.0) return 0;

    p->treatments[index] = t;
    return 1;
}

int deleteTreatment(Patient *p, int index) {
    if (!p) return 0;
    if (index < 0 || index >= p->treatmentCount) return 0;

    for (int i = index; i < p->treatmentCount - 1; ++i) {
        p->treatments[i] = p->treatments[i + 1];
    }
    p->treatmentCount--;
    return 1;
}

/* ---------- interactive demo ---------- */

static void inputDoctor(Doctor *d) {
    char buf[MAX_STR];

    read_line("Doctor name: ", buf, sizeof(buf));
    strncpy(d->name, buf, MAX_STR - 1); d->name[MAX_STR - 1] = '\0';

    read_line("Specialty: ", buf, sizeof(buf));
    strncpy(d->specialty, buf, MAX_STR - 1); d->specialty[MAX_STR - 1] = '\0';

    int room = 0;
    if (!read_int("Room number (>0): ", &room)) room = 0;
    d->room = room;
}

static void inputTreatment(Treatment *t) {
    char buf[MAX_DESC];

    read_line("Date (YYYY-MM-DD): ", t->date, sizeof(t->date));

    read_line("Description: ", buf, sizeof(buf));
    strncpy(t->description, buf, MAX_DESC - 1); t->description[MAX_DESC - 1] = '\0';

    double cost = 0.0;
    if (!read_double("Cost (>=0): ", &cost)) cost = -1.0;
    t->cost = cost;
}

static void printMenu(void) {
    printf("Menu:\n");
    printf(" 1) Assign doctor\n");
    printf(" 2) Add treatment\n");
    printf(" 3) Modify treatment\n");
    printf(" 4) Delete treatment\n");
    printf(" 5) Display patient\n");
    printf(" 6) Patient summary\n");
    printf(" 0) Exit\n");
}

int main(void) {
    Patient p;
    initPatient(&p, 1001, "Sila Canbolat", 19);

    /* Pre-fill a couple of records */
    Doctor d0 = {"Dr. Olena Kovalenko", "Therapist", 210};
    assignDoctor(&p, d0);

    Treatment t0 = {"2025-11-10", "Initial consultation", 25.00};
    Treatment t1 = {"2025-11-12", "Blood test", 18.50};
    addTreatment(&p, t0);
    addTreatment(&p, t1);

    int choice = -1;
    while (choice != 0) {
        printMenu();
        if (!read_int("Choose: ", &choice)) {
            printf("Invalid input. Try again.\n\n");
            continue;
        }

        if (choice == 1) {
            Doctor d;
            inputDoctor(&d);
            if (assignDoctor(&p, d)) printf("OK: doctor assigned.\n\n");
            else printf("ERROR: invalid doctor data.\n\n");
        } else if (choice == 2) {
            Treatment t;
            inputTreatment(&t);
            if (addTreatment(&p, t)) printf("OK: treatment added.\n\n");
            else printf("ERROR: cannot add treatment (check date/desc/cost or capacity).\n\n");
        } else if (choice == 3) {
            int idx = -1;
            if (!read_int("Index to modify: ", &idx)) {
                printf("ERROR: invalid index.\n\n");
                continue;
            }
            Treatment t;
            inputTreatment(&t);
            if (modifyTreatment(&p, idx, t)) printf("OK: treatment modified.\n\n");
            else printf("ERROR: cannot modify (invalid index or invalid treatment data).\n\n");
        } else if (choice == 4) {
            int idx = -1;
            if (!read_int("Index to delete: ", &idx)) {
                printf("ERROR: invalid index.\n\n");
                continue;
            }
            if (deleteTreatment(&p, idx)) printf("OK: treatment deleted.\n\n");
            else printf("ERROR: cannot delete (invalid index).\n\n");
        } else if (choice == 5) {
            displayPatient(&p);
        } else if (choice == 6) {
            printPatientSummary(&p);
        } else if (choice == 0) {
            printf("Bye!\n");
        } else {
            printf("Unknown option.\n\n");
        }
    }

    return 0;
}
