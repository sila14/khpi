# Lab Work #9 — Structs in C (Variant 3: Hospital Patient Record)

**Student:** Sıla Canbolat (КН-925і.е, ННİ КНІТ)  
**Instructor:** Volodymyr Savchenko  
**Year:** 2025

## Objective
I did practice working with nested `struct` types in C and writing safe functions that edit the records.

## Variant and task
Variant **3**: **Hospital Patient Record** — structs **Patient**, **Doctor**, **Treatment**.  
Patient contains one Doctor and an array of Treatment records. fileciteturn19file0L29-L35

Required functions:
- `assignDoctor(Patient*, Doctor)`
- `addTreatment(Patient*, Treatment)`
- `getPatientSummary(Patient*)` (implemented as `printPatientSummary(const Patient*)`) fileciteturn19file0L32-L35

Additionally, I implemented modify/delete/display utilities, because the lab asks for full manipulation and error handling. fileciteturn19file0L7-L11

## Error handling
Afterwards I added checks for:
- capacity (`MAX_TREATMENTS`)
- valid date format `YYYY-MM-DD`
- non-empty required strings
- non-negative cost
- index bounds for modify/delete

## Build and run
After that I compiled and ran the program:
```bash
gcc -Wall -Wextra -std=c11 lab9_variant03.c -o lab9
./lab9
```

## Test cases (short)
Finally I tested:
1) normal add + display  
2) add with invalid date → error  
3) delete with invalid index → error  
4) modify existing treatment → ok  

## Debug session (example 10–20 lines)
```gdb
(gdb) break addTreatment
Breakpoint 1 at 0x...
(gdb) run
Starting program: ./lab9
(gdb) continue
Breakpoint 1, addTreatment (...) at lab9_variant03.c:...
(gdb) print p->treatmentCount
$1 = 2
(gdb) print t.date
$2 = "2025-11-15"
(gdb) print t.cost
$3 = 30
(gdb) next
(gdb) print p->treatmentCount
$4 = 3
(gdb) continue
```

## Files submitted
- `lab9_variant03.c`
- `Report.md`
