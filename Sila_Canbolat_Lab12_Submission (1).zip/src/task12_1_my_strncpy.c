/*
 * Lab Work #12 — C-strings
 * Task 1 (Variant 3): Implement strncpy() WITHOUT <string.h>
 * Student: Sıla Canbolat (КН-925і.е, ННІ КНІТ)
 *
 * Rules:
 * - Do NOT include <string.h>
 * - Use only pointer operations
 */

#include <stdio.h>
#include <stddef.h>  /* size_t */

/* my_strncpy:
 * Copies up to n characters from src to dest.
 * If src ends before n, the remaining bytes are filled with '\0'.
 * Returns dest.
 */
char *my_strncpy(char *dest, const char *src, size_t n) {
    if (!dest || !src) return dest;

    char *d = dest;
    const char *s = src;

    /* copy while n > 0 and src not ended */
    while (n > 0 && *s != '\0') {
        *d = *s;
        ++d;
        ++s;
        --n;
    }

    /* pad with '\0' until n == 0 */
    while (n > 0) {
        *d = '\0';
        ++d;
        --n;
    }

    return dest;
}

/* Helper: print bytes of a buffer to show padding */
static void print_bytes(const char *label, const unsigned char *buf, size_t n) {
    printf("%s (bytes): ", label);
    for (size_t i = 0; i < n; ++i) {
        printf("%02X ", buf[i]);
    }
    printf("\n");
}

int main(void) {
    printf("Task 1 — my_strncpy() tests\n\n");

    /* Test 1: src longer than n */
    {
        char dest[16] = {0};
        const char *src = "HELLO_WORLD";
        my_strncpy(dest, src, 5);
        printf("Test 1: src=\"%s\", n=5\n", src);
        printf("dest as string: \"%s\"\n", dest);
        print_bytes("dest", (unsigned char*)dest, 16);
        printf("\n");
    }

    /* Test 2: src shorter than n -> padding with zeros */
    {
        char dest[16];
        /* Fill dest with 'X' so padding is visible */
        for (size_t i = 0; i < 16; ++i) dest[i] = 'X';

        const char *src = "ABC";
        my_strncpy(dest, src, 10);
        printf("Test 2: src=\"%s\", n=10\n", src);
        printf("dest as string: \"%s\"\n", dest);
        print_bytes("dest", (unsigned char*)dest, 16);
        printf("\n");
    }

    /* Test 3: n = 0 -> no changes */
    {
        char dest[16] = "ORIGINAL";
        const char *src = "NEW";
        my_strncpy(dest, src, 0);
        printf("Test 3: src=\"%s\", n=0\n", src);
        printf("dest as string: \"%s\"\n", dest);
        print_bytes("dest", (unsigned char*)dest, 16);
        printf("\n");
    }

    /* Test 4: copy full string including terminator by using n >= len+1 */
    {
        char dest[16];
        for (size_t i = 0; i < 16; ++i) dest[i] = 'Z';
        const char *src = "OK";
        my_strncpy(dest, src, 3); /* O K \0 */
        printf("Test 4: src=\"%s\", n=3\n", src);
        printf("dest as string: \"%s\"\n", dest);
        print_bytes("dest", (unsigned char*)dest, 16);
        printf("\n");
    }

    return 0;
}
