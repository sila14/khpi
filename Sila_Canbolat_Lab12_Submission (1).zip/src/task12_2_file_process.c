/*
 * Lab Work #12 — C-strings and file operations
 * Task 2 (Variant 3):
 *   1) Remove all vowels from the text
 *   2) Replace // single-line comments with block-style comments
 *
 * Student: Sıla Canbolat (КН-925і.е, ННІ КНІТ)
 */

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <ctype.h>

#define IN_NAME  "input.txt"
#define OUT_NAME "output.txt"
#define LINE_CAP 512

static int is_vowel(int ch) {
    ch = tolower((unsigned char)ch);
    return (ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u');
}

/* remove_vowels_inplace: removes vowels by shifting the buffer */
static void remove_vowels_inplace(char *s) {
    if (!s) return;
    char *r = s; /* read */
    char *w = s; /* write */
    while (*r) {
        if (!is_vowel((unsigned char)*r)) {
            *w++ = *r;
        }
        ++r;
    }
    *w = '\0';
}

/* convert_slash_comment_to_block: converts // comments outside quotes into block-style comments. */
static int convert_slash_comment_to_block(const char *in, char *out, size_t cap) {
    int in_dquote = 0; /* "..." */
    int in_squote = 0; /* 'c'   */
    int escaped = 0;
    size_t oi = 0;
    int converted = 0;

    for (size_t i = 0; in[i] != '\0'; ++i) {
        char c = in[i];

        /* Handle newline at end: copy and stop */
        if (c == '\n') {
            if (oi + 1 < cap) out[oi++] = '\n';
            break;
        }

        if (!escaped) {
            if (!in_squote && c == '"') in_dquote = !in_dquote;
            else if (!in_dquote && c == '\'') in_squote = !in_squote;
        }

        /* Escape handling inside quotes */
        if ((in_dquote || in_squote) && c == '\\' && !escaped) {
            escaped = 1;
        } else {
            escaped = 0;
        }

        /* Detect // only when not inside quotes and not already converted */
        if (!converted && !in_dquote && !in_squote && c == '/' && in[i+1] == '/') {
            /* write slash-star */
            if (oi + 2 >= cap) break;
            out[oi++] = '/';
            out[oi++] = '*';

            /* copy the rest of comment after '//' until end-of-line */
            i += 2;
            for (; in[i] != '\0' && in[i] != '\n'; ++i) {
                if (oi + 1 >= cap) break;
                out[oi++] = in[i];
            }

            /* write star-slash */
            if (oi + 2 < cap) {
                out[oi++] = '*';
                out[oi++] = '/';
            }
            converted = 1;

            /* if we stopped because of '\n', preserve it */
            if (in[i] == '\n' && oi + 1 < cap) out[oi++] = '\n';
            break;
        }

        /* normal copy */
        if (oi + 1 < cap) out[oi++] = c;
    }

    if (oi >= cap) oi = cap - 1;
    out[oi] = '\0';
    return converted;
}

/* process_file:
 * Reads IN_NAME line by line, applies both transformations, writes OUT_NAME.
 */
static int process_file(const char *in_path, const char *out_path) {
    FILE *fin = fopen(in_path, "r");
    if (!fin) {
        perror("Cannot open input file");
        return 0;
    }

    FILE *fout = fopen(out_path, "w");
    if (!fout) {
        perror("Cannot open output file");
        fclose(fin);
        return 0;
    }

    char line[LINE_CAP];
    char tmp[LINE_CAP * 2]; /* comment expansion room */
    int lines = 0, converted = 0;

    while (fgets(line, sizeof(line), fin)) {
        lines++;

        /* Step 1: convert // comment into block-style comment */
        int did = convert_slash_comment_to_block(line, tmp, sizeof(tmp));
        if (did) converted++;

        /* Step 2: remove vowels from the resulting line */
        remove_vowels_inplace(tmp);

        fputs(tmp, fout);
        /* ensure file stays line-based even if vowels removed '\n' (unlikely) */
        if (tmp[0] != '\0') {
            size_t L = 0;
            while (tmp[L] != '\0') L++;
            if (L > 0 && tmp[L-1] != '\n') fputc('\n', fout);
        } else {
            fputc('\n', fout);
        }
    }

    fclose(fin);
    fclose(fout);

    printf("OK: processed %d line(s). Converted comments: %d\n", lines, converted);
    return 1;
}

int main(void) {
    printf("Task 2 — file processing (Variant 3)\n");
    printf("Input : %s\nOutput: %s\n\n", IN_NAME, OUT_NAME);

    if (!process_file(IN_NAME, OUT_NAME)) {
        printf("ERROR: file processing failed.\n");
        return 1;
    }

    printf("Done.\n");
    return 0;
}
