# Lab Work #12 — C-Strings (Pointers) and File Operations

**Student:** Sıla Canbolat — Group **КН-925і.е** (ННІ КНІТ)  
**Instructor:** Volodymyr Savchenko  
**Year:** 2025

---

## Objective
I did practice low-level work with **C-strings**: implementing a classic string function from scratch using **only pointers** (no `<string.h>`). Afterwards I implemented file processing where I read a text file, modified the lines, and saved the result into a new file.

---

## Task 1 — Implement a standard C-string function (Variant 3 → `strncpy`)
### Function selected
Afterwards I selected list item **#3** from the function table: `strncpy()` (copy N characters).

### Implemented signature
```c
char *my_strncpy(char *dest, const char *src, size_t n);
```

### What the function does
- Copy up to `n` characters from `src` into `dest`.
- If `src` ends earlier, pad the rest of `dest` with `\0`.
- Return `dest`.

### Documentation table (Task 1)
| Function Name | Purpose | Parameters | Return Value | Example |
|---|---|---|---|---|
| `my_strncpy` | Copy up to `n` chars, pad with `\0` | `dest, src, n` | `dest` | `my_strncpy(d,"ABC",10);` |

### Test runs
I did test four scenarios:
1) `src` longer than `n`  
2) `src` shorter than `n` (zero padding)  
3) `n = 0` (no change)  
4) `n = len(src)+1` (copies terminator)  

---

## Task 2 — File operations + string manipulations (Variant 3)
Finally I implemented Variant **3** from the modifications table:

1) Remove **all vowels** (A/E/I/O/U in any case).  
2) Convert `//` **single-line comments** into **block-style comments** when `//` occurs outside quotes.

### Approach
- I did read the file line-by-line with `fgets`.
- Afterwards I converted `//` comment to block-style for each line (only if not inside quotes).
- After that I removed vowels in-place by shifting characters.
- Finally I wrote the line to `output.txt`.

### Sample input (`input.txt`)
```text
hello world // comment with vowels
This line has NO comment.
C is great! // TODO: improve code
printf("http://example.com"); // url inside string should keep // in quotes
AEIOU aeiou vowels everywhere
```

### Sample output (`output.txt`)
```text
hll wrld /* cmmnt wth vwls*/
Ths ln hs N cmmnt.
C s grt! /* TD: mprv cd*/
prntf("http://xmpl.cm"); /* rl nsd strng shld kp // n qts*/
  vwls vrywhr
```

---

## Build and run
```bash
make
./build_task1
./build_task2
```

---

## Debug session (example 10–20 lines)
```gdb
(gdb) break my_strncpy
(gdb) run
(gdb) print n
$1 = 10
(gdb) next
(gdb) print *src
$2 = 65 'A'
(gdb) next
(gdb) print *dest
$3 = 65 'A'
(gdb) continue
(gdb) break convert_slash_comment_to_block
(gdb) run
(gdb) next
(gdb) print converted
$4 = 1
(gdb) continue
```

---

## Source files
- `src/task12_1_my_strncpy.c`
- `src/task12_2_file_process.c`
- `input.txt`, `output.txt`
- `Makefile`

---

## References
- Lab Work #12 handout (C-strings + file operations).
- C standard I/O functions: `fopen`, `fclose`, `fgets`, `fputs`, `fprintf`.
