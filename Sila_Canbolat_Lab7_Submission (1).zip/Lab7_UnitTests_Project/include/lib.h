#ifndef LIB_H_
#define LIB_H_

/*
  Lab Work #7 - Function Library + Unit Tests (Unity)
  Variant 03: expressions {3, 7, 12, 17}

  Each function returns the computed value.
  If the input is outside the domain, the function returns NAN and sets *ok = 0.
  Otherwise, *ok = 1.

  Note: This header is intentionally small and clean.
*/

#include <math.h>

double expr03(double x, double y, double z, double w, double v, int *ok);
double expr07(double x, double y, double z, double w, double v, int *ok);
double expr12(double x, double y, double z, double w, int *ok);
double expr17(double x, double y, double z, double w, int *ok);

#endif /* LIB_H_ */
