# Report — Lab Work #7: Unit Tests (C)

**Student:** Sıla Canbolat  
**Group:** КН-925і.е  
**Institute:** ННІ КНІТ  
**Discipline:** Programming (C)  
**Lab:** #7 — Implementing a Function Library with Unit Testing

---

## 1. Objective
In this lab I implemented four mathematical expressions as library functions, then I wrote unit tests for each function using a Unity-style framework, and after that I generated a code coverage report.

---

## 2. Variant information
I used **Variant 03**, so I implemented the following expressions:

- **Function 1 (No. 3)**  
  \[
  E_3 = \frac{(e^{x} - \sin(y))\cdot z}{\cos(w) + \tan(v)}
  \]

- **Function 2 (No. 7)**  
  \[
  E_7 = \frac{x}{y + \tan(z)}\cdot \cos(w) - \ln(v + 1)
  \]

- **Function 3 (No. 12)**  
  \[
  E_{12} = (x - \sin(y))\cdot z^2 + e^{w}
  \]

- **Function 4 (No. 17)**  
  \[
  E_{17} = x\cdot (\sin(y) - \sqrt{z}) + e^{w}
  \]

---

## 3. Project structure
After I created a new folder for the lab, I organized the files using the required structure:

```
project/
  include/       (lib.h)
  src/           (lib.c)
  test/          (test_lib.c, test_main.c)
  Unity/         (Unity test harness)
  main.c
  Makefile
  README.md
```

---

## 4. Domain of definition (input validation)
Before I returned the result, I checked the domain rules and if the input was invalid I returned **NaN** and set `ok = 0`.

### 4.1 E3
- `tan(v)` exists only if `cos(v) != 0`
- denominator must be non-zero: `cos(w) + tan(v) != 0`

### 4.2 E7
- `tan(z)` exists only if `cos(z) != 0`
- denominator must be non-zero: `y + tan(z) != 0`
- `ln(v+1)` exists only if `v+1 > 0`

### 4.3 E12
- defined for all real numbers

### 4.4 E17
- `sqrt(z)` exists only if `z >= 0`

---

## 5. Implementation details
After I created the header file `include/lib.h`, I wrote the function implementations in `src/lib.c`.

Functions implemented:
- `double expr03(double x, double y, double z, double w, double v, int *ok);`
- `double expr07(double x, double y, double z, double w, double v, int *ok);`
- `double expr12(double x, double y, double z, double w, int *ok);`
- `double expr17(double x, double y, double z, double w, int *ok);`

---

## 6. Unit tests
Afterwards, I created the unit tests in `test/test_lib.c` and connected them in `test/test_main.c`.

### 6.1 What I tested
For each expression I tested:
- one **normal** case (valid input)
- one **edge/invalid** case (domain violation)

Examples:
- `expr03`: invalid when `v = pi/2` (tan undefined)
- `expr07`: invalid when `v = -1` (ln(0))
- `expr17`: invalid when `z < 0` (sqrt)

---

## 7. Building and running
After I finished the code, I built and ran everything using the Makefile.

Commands I used:
```bash
make
./build/app
make test
make coverage
```

---

## 8. Coverage report
Finally, I generated coverage using `gcov` (via `make coverage`), and I saved the report text to:

- `coverage_report/gcov_lib.txt`

This report shows line-level and branch-level coverage for the library source file.

---

## 9. Conclusion
In this lab I created a small C library with four mathematical functions, and after that I verified correctness using unit tests. Finally, I checked my implementation quality by generating a coverage report and reviewing which lines were executed during the test run.
