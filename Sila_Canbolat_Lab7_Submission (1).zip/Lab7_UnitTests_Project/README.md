# Lab Work #7 - Unit Tests (C)

Variant: 03 (expressions 3, 7, 12, 17)

## What I built
- A small math library in `src/lib.c` with prototypes in `include/lib.h`
- A demo program `main.c`
- A unit test suite under `test/` using a tiny Unity-compatible harness inside `Unity/`
- Coverage generation using `gcov`

## How to run
```bash
make            # build build/app
./build/app     # run demo program
make test       # run unit tests
make coverage   # generate gcov report in coverage_report/
```

Notes:
- This project links with `-lm` because it uses math functions.
- If your teacher requires the official Unity repo, you can replace the `Unity/` folder with:
  `git clone git@github.com:ThrowTheSwitch/Unity.git`
