#include "lib.h"
#include <float.h>

static int near_zero(double a) {
    return fabs(a) < 1e-12;
}

/*
  Expression 3:
  E3 = (exp(x) - sin(y)) * z / (cos(w) + tan(v))

  Domain:
  - tan(v) defined => cos(v) != 0
  - denominator cos(w) + tan(v) != 0
*/
double expr03(double x, double y, double z, double w, double v, int *ok)
{
    if (ok) *ok = 0;

    double cv = cos(v);
    if (near_zero(cv)) return NAN;              /* tan(v) undefined */

    double t_v = tan(v);
    double denom = cos(w) + t_v;
    if (near_zero(denom)) return NAN;

    double a = exp(x);
    double b = sin(y);
    double num = (a - b) * z;

    if (ok) *ok = 1;
    return num / denom;
}

/*
  Expression 7:
  E7 = x/(y + tan(z)) * cos(w) - ln(v + 1)

  Domain:
  - tan(z) defined => cos(z) != 0
  - y + tan(z) != 0
  - ln(v+1) defined => v + 1 > 0
*/
double expr07(double x, double y, double z, double w, double v, int *ok)
{
    if (ok) *ok = 0;

    if (v + 1.0 <= 0.0) return NAN;

    double cz = cos(z);
    if (near_zero(cz)) return NAN;              /* tan(z) undefined */

    double t_z = tan(z);
    double denom = y + t_z;
    if (near_zero(denom)) return NAN;

    double part1 = (x / denom) * cos(w);
    double part2 = log(v + 1.0);

    if (ok) *ok = 1;
    return part1 - part2;
}

/*
  Expression 12:
  E12 = (x - sin(y)) * z^2 + exp(w)

  Domain: all real numbers (no division, no log, no sqrt).
*/
double expr12(double x, double y, double z, double w, int *ok)
{
    if (ok) *ok = 1;

    double s = sin(y);
    double z2 = z * z;
    double left = (x - s) * z2;
    double right = exp(w);

    return left + right;
}

/*
  Expression 17:
  E17 = x * (sin(y) - sqrt(z)) + exp(w)

  Domain:
  - sqrt(z) defined => z >= 0
*/
double expr17(double x, double y, double z, double w, int *ok)
{
    if (ok) *ok = 0;
    if (z < 0.0) return NAN;

    double s = sin(y);
    double r = sqrt(z);
    double left = x * (s - r);
    double right = exp(w);

    if (ok) *ok = 1;
    return left + right;
}
