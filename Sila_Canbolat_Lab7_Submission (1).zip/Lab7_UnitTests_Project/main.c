#include <stdio.h>
#include <math.h>
#include "lib.h"

static void print_result(const char *name, double value, int ok)
{
    if (!ok || isnan(value)) {
        printf("%s = NaN (invalid input)\n", name);
    } else {
        printf("%s = %.10f\n", name, value);
    }
}

int main(void)
{
    /* Simple demo: read 5 numbers for E3 and E7, then 4 numbers for E12 and E17. */
    double x, y, z, w, v;
    int ok = 0;

    printf("Lab 7 demo (Variant 03). Enter x y z w v for expr03:\n");
    if (scanf("%lf %lf %lf %lf %lf", &x, &y, &z, &w, &v) != 5) {
        printf("Input error.\n");
        return 1;
    }
    double e3 = expr03(x, y, z, w, v, &ok);
    print_result("expr03", e3, ok);

    printf("\nEnter x y z w v for expr07:\n");
    if (scanf("%lf %lf %lf %lf %lf", &x, &y, &z, &w, &v) != 5) {
        printf("Input error.\n");
        return 1;
    }
    double e7 = expr07(x, y, z, w, v, &ok);
    print_result("expr07", e7, ok);

    printf("\nEnter x y z w for expr12:\n");
    if (scanf("%lf %lf %lf %lf", &x, &y, &z, &w) != 4) {
        printf("Input error.\n");
        return 1;
    }
    double e12 = expr12(x, y, z, w, &ok);
    print_result("expr12", e12, ok);

    printf("\nEnter x y z w for expr17:\n");
    if (scanf("%lf %lf %lf %lf", &x, &y, &z, &w) != 4) {
        printf("Input error.\n");
        return 1;
    }
    double e17 = expr17(x, y, z, w, &ok);
    print_result("expr17", e17, ok);

    return 0;
}
