#include "unity.h"

/* Declarations of test functions */
void test_expr03_valid(void);
void test_expr03_invalid_tan(void);
void test_expr07_valid(void);
void test_expr07_invalid_log(void);
void test_expr12_valid(void);
void test_expr17_valid(void);
void test_expr17_invalid_sqrt(void);

int main(void)
{
    UNITY_BEGIN();

    RUN_TEST(test_expr03_valid);
    RUN_TEST(test_expr03_invalid_tan);

    RUN_TEST(test_expr07_valid);
    RUN_TEST(test_expr07_invalid_log);

    RUN_TEST(test_expr12_valid);

    RUN_TEST(test_expr17_valid);
    RUN_TEST(test_expr17_invalid_sqrt);

    return UNITY_END();
}
