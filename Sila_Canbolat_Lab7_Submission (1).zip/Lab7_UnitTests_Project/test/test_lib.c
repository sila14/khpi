#include "unity.h"
#include <math.h>
#include "lib.h"

/* required by Unity style */
void setUp(void) {}
void tearDown(void) {}

static double ref_expr03(double x,double y,double z,double w,double v) {
    return (exp(x) - sin(y)) * z / (cos(w) + tan(v));
}
static double ref_expr07(double x,double y,double z,double w,double v) {
    return (x / (y + tan(z))) * cos(w) - log(v + 1.0);
}
static double ref_expr12(double x,double y,double z,double w) {
    return (x - sin(y)) * (z*z) + exp(w);
}
static double ref_expr17(double x,double y,double z,double w) {
    return x * (sin(y) - sqrt(z)) + exp(w);
}

void test_expr03_valid(void)
{
    int ok = 0;
    double x=0.3, y=0.1, z=2.0, w=0.4, v=0.2;
    double got = expr03(x,y,z,w,v,&ok);
    double expv = ref_expr03(x,y,z,w,v);
    TEST_ASSERT_TRUE(ok);
    TEST_ASSERT_DOUBLE_WITHIN(1e-10, expv, got);
}

void test_expr03_invalid_tan(void)
{
    int ok = 1;
    /* v = pi/2 -> cos(v)=0, tan undefined */
    const double PI = 3.14159265358979323846;
    double v = PI/2.0;
    double got = expr03(0.2,0.1,1.0,0.3,v,&ok);
    TEST_ASSERT_FALSE(ok);
    TEST_ASSERT_TRUE(isnan(got));
}

void test_expr07_valid(void)
{
    int ok = 0;
    double x=1.2, y=0.7, z=0.2, w=1.0, v=2.0;
    double got = expr07(x,y,z,w,v,&ok);
    double expv = ref_expr07(x,y,z,w,v);
    TEST_ASSERT_TRUE(ok);
    TEST_ASSERT_DOUBLE_WITHIN(1e-10, expv, got);
}

void test_expr07_invalid_log(void)
{
    int ok = 1;
    double got = expr07(1.0,1.0,0.2,0.3,-1.0,&ok); /* v+1 = 0 -> ln undefined */
    TEST_ASSERT_FALSE(ok);
    TEST_ASSERT_TRUE(isnan(got));
}

void test_expr12_valid(void)
{
    int ok = 0;
    double x=-2.0, y=0.5, z=3.0, w=0.0;
    double got = expr12(x,y,z,w,&ok);
    double expv = ref_expr12(x,y,z,w);
    TEST_ASSERT_TRUE(ok);
    TEST_ASSERT_DOUBLE_WITHIN(1e-12, expv, got);
}

void test_expr17_valid(void)
{
    int ok = 0;
    double x=1.5, y=0.25, z=4.0, w=-0.1;
    double got = expr17(x,y,z,w,&ok);
    double expv = ref_expr17(x,y,z,w);
    TEST_ASSERT_TRUE(ok);
    TEST_ASSERT_DOUBLE_WITHIN(1e-12, expv, got);
}

void test_expr17_invalid_sqrt(void)
{
    int ok = 1;
    double got = expr17(1.0,0.2,-0.001,0.0,&ok);
    TEST_ASSERT_FALSE(ok);
    TEST_ASSERT_TRUE(isnan(got));
}
