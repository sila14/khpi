#ifndef UNITY_H
#define UNITY_H

/*
  Tiny Unity-like test harness (enough for this lab).
  It mimics the Unity public API used in typical assignments:
  - UNITY_BEGIN / UNITY_END
  - RUN_TEST(fn)
  - TEST_ASSERT_... helpers

  This is not the full upstream Unity project.
*/

#include <stdio.h>
#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif

extern int UnityFailCount;
extern int UnityTestCount;

void UnityBegin(const char *name);
int  UnityEnd(void);

void UnityRunTest(void (*test)(void), const char *test_name, int line);

void UnityAssertTrue(int condition, const char *msg, int line);
void UnityAssertDoubleWithin(double delta, double expected, double actual, const char *msg, int line);

#define UNITY_BEGIN()      do { UnityBegin(__FILE__); } while(0)
#define UNITY_END()        UnityEnd()

#define RUN_TEST(fn)       do { UnityRunTest((fn), #fn, __LINE__); } while(0)

#define TEST_ASSERT_TRUE(cond) \
    do { UnityAssertTrue((cond), #cond, __LINE__); } while(0)

#define TEST_ASSERT_FALSE(cond) \
    do { UnityAssertTrue(!(cond), "!(" #cond ")", __LINE__); } while(0)

#define TEST_ASSERT_DOUBLE_WITHIN(delta, expected, actual) \
    do { UnityAssertDoubleWithin((delta), (expected), (actual), #actual, __LINE__); } while(0)

#ifdef __cplusplus
}
#endif

#endif /* UNITY_H */
