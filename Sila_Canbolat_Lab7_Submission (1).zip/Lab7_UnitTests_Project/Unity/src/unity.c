#include "unity.h"

int UnityFailCount = 0;
int UnityTestCount = 0;

static const char *g_file = "tests";

void UnityBegin(const char *name)
{
    g_file = name ? name : "tests";
    UnityFailCount = 0;
    UnityTestCount = 0;
    printf("== Unity: %s ==\n", g_file);
}

static void report_fail(const char *msg, int line)
{
    UnityFailCount++;
    printf("[FAIL] %s:%d: %s\n", g_file, line, msg ? msg : "(no message)");
}

void UnityAssertTrue(int condition, const char *msg, int line)
{
    if (!condition) report_fail(msg, line);
}

void UnityAssertDoubleWithin(double delta, double expected, double actual, const char *msg, int line)
{
    double diff = fabs(expected - actual);
    if (isnan(expected) && isnan(actual)) return;
    if (diff > fabs(delta) || isnan(actual) || isnan(expected)) {
        char buf[256];
        snprintf(buf, sizeof(buf),
                 "%s: expected %.17g, got %.17g, |diff|=%.17g > %.17g",
                 msg ? msg : "double", expected, actual, diff, delta);
        report_fail(buf, line);
    }
}

void UnityRunTest(void (*test)(void), const char *test_name, int line)
{
    (void)line;
    UnityTestCount++;
    printf("-- RUN %s\n", test_name ? test_name : "(unnamed)");
    if (test) test();
}

int UnityEnd(void)
{
    printf("== Summary: %d tests, %d failures ==\n", UnityTestCount, UnityFailCount);
    return UnityFailCount;
}
