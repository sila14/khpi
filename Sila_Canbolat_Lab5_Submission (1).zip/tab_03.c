#include <stdio.h>
#include <math.h>

/*
 * Lab 05_02 — Function Tabulation
 * Variant 03 (odd) => use DO ... WHILE
 * y = x * sin(pi + x/15) / (pi + x/15)^2,  x in [0; 3]
 */

int main(void)
{
    int n;
    if (scanf("%d", &n) != 1 || n <= 0) {
        puts("Invalid n");
        return 1;
    }

    const double a = 0.0;
    const double b = 3.0;

    if (n == 1) {
        double x = a;
        double denom = M_PI + x / 15.0;
        double y = x * sin(M_PI + x / 15.0) / (denom * denom);
        printf("%10.5f %12.5f\n", x, y);
        return 0;
    }

    double h = (b - a) / (n - 1);
    int i = 0;
    double x = a;

    do {
        double denom = M_PI + x / 15.0;
        double y;

        if (denom == 0.0) {
            y = NAN;
        } else {
            y = x * sin(M_PI + x / 15.0) / (denom * denom);
        }

        printf("%10.5f %12.5f\n", x, y);

        ++i;
        x = a + i * h;
    } while (i < n);

    return 0;
}
