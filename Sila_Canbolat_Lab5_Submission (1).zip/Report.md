# Lab work #5 — Loops (C)

**Student:** Sıla Canbolat  
**Group:** КН-925і.е  
**Institute:** ННІ КНІТ, NTU “KhPI”  
**Discipline:** Programming. Part 1 (C)  
**Variant:** 03 (used for 05_01, 05_02, 05_03)

---

## What I did (short story version)
I started by reading the Lab 05 instructions and identified that Variant 03 is an **odd** variant, so I used **while / do...while** where required. Afterwards, I implemented each subtask in a separate C source file and prepared a small set of test runs. After that, I ran each program under **GDB** and captured a short transcript (10–20 lines) to show variable changes. Finally, I summarized the formulas, algorithms, and outputs below.

---

## 05_01 — Series sums/products (Variant 03)

### Formula
\[
S = \sum_{k=0}^m \frac{a^k \cdot \tan(x + 0.5k)}{a + kx}
\]

### Files
- `series_03_int.c` (FOR loop)
- `series_03_fp.c` (WHILE loop)

### Input format
`m a x`  
Example: `5 2 0.3`

### Domain / validity notes
- Denominator **a + kx ≠ 0** for every k in [0..m]  
- tan() must be finite at (x + 0.5k). If any term is invalid, the program prints **NaN**.

### Sample outputs (same input for both versions)
Input: `5 2 0.3`  
Result: `-14.07909473`

Input: `3 1.5 0.2`  
Result: `-8.445234473`

Input: `10 0.9 0.1`  
Result: `-17.78822926`

### Debug session transcript (example)
```text
gcc -g -O0 -Wall -Wextra series_03_int.c -lm -o series_int
gdb ./series_int
(gdb) break main
(gdb) run
# input: 5 2 0.3
(gdb) next
(gdb) print m
(gdb) print a
(gdb) print x
(gdb) next
(gdb) print k
(gdb) print apow
(gdb) print denom
(gdb) print t
(gdb) print term
(gdb) continue
```

---

## 05_02 — Function tabulation (Variant 03)

### Function and range
\[
y = \frac{x \cdot \sin(\pi + x/15)}{(\pi + x/15)^2}, \quad x \in [0;3]
\]

### File
- `tab_03.c` (DO...WHILE loop)

### Input format
`n` (number of points, n > 0)

### Domain of definition (DOD)
- (π + x/15)² is always positive for real x, so the function is defined for all x in [0;3].

### Example output (n = 7)
```text
      x            y
   0.00000      0.00000
   0.50000     -0.00165
   1.00000     -0.00647
   1.50000     -0.01425
   2.00000     -0.02479
   2.50000     -0.03789
   3.00000     -0.05338
```

### Debug session transcript (example)
```text
gcc -g -O0 -Wall -Wextra tab_03.c -lm -o tab_03
gdb ./tab_03
(gdb) break main
(gdb) run
# input: 7
(gdb) print n
(gdb) next
(gdb) print h
(gdb) print i
(gdb) print x
(gdb) print y
(gdb) continue
```

---

## 05_03 — Base conversion (Variant 03)

### Variant pair
- a = 10, b = 4

### File
- `base_03.c`

### Method (no arrays, no user functions)
- 10 → 4: find largest power p = 4^k ≤ N, then print digits using N/p and update N %= p, p /= 4.
- 4 → 10: read the base-4 number as a decimal integer (digits 0..3) and accumulate using place values.

### Test examples
- 10 → 4: 255 → 3333  
- 10 → 4: 26 → 122  
- 4 → 10: 1203 → 99

### Debug session transcript (example)
```text
gcc -g -O0 -Wall -Wextra base_03.c -o base_03
gdb ./base_03
(gdb) break main
(gdb) run
# mode: 1
# n: 255
(gdb) next
(gdb) print mode
(gdb) print n
(gdb) print p
(gdb) next
(gdb) print digit
(gdb) continue
```

---

## Build commands (quick)
```bash
gcc -Wall -Wextra -O2 series_03_int.c -lm -o series_int
gcc -Wall -Wextra -O2 series_03_fp.c -lm -o series_fp
gcc -Wall -Wextra -O2 tab_03.c -lm -o tab_03
gcc -Wall -Wextra -O2 base_03.c -o base_03
```
