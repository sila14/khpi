#include <stdio.h>

/*
 * Lab 05_03 — Base Conversion (2..10)
 * Variant 03: a = 10, b = 4
 *
 * Requirements: no arrays, no user-defined functions, use only multiplication/division.
 * Implement both directions: 10 -> 4 and 4 -> 10.
 */

int main(void)
{
    const unsigned a = 10;
    const unsigned b = 4;

    int mode;
    printf("Choose mode (1 = 10->4, 2 = 4->10): ");
    if (scanf("%d", &mode) != 1 || (mode != 1 && mode != 2)) {
        puts("Invalid mode");
        return 1;
    }

    if (mode == 1) {
        /* 10 -> 4 */
        unsigned long long n;
        printf("Decimal n: ");
        if (scanf("%llu", &n) != 1) {
            puts("Input error");
            return 2;
        }

        /* find largest power p = b^k <= n */
        unsigned long long p = 1;
        while (p <= n / b) {
            p *= b;
        }

        printf("Base-%u: ", b);

        if (n == 0) {
            putchar('0');
        } else {
            while (p > 0) {
                unsigned digit = (unsigned)(n / p); /* 0..(b-1) */
                putchar((char)('0' + digit));
                n %= p;
                p /= b;
            }
        }

        putchar('\n');
    } else {
        /* 4 -> 10  (input digits 0..3, given as an integer like 1203) */
        unsigned long long in;
        printf("Base-%u number (digits 0..3): ", b);
        if (scanf("%llu", &in) != 1) {
            puts("Input error");
            return 3;
        }

        unsigned long long value = 0;
        unsigned long long place = 1;

        while (1) {
            unsigned digit = (unsigned)(in % 10ULL);
            if (digit >= b) {
                puts("Invalid digit for base 4");
                return 4;
            }

            value += (unsigned long long)digit * place;

            in /= 10ULL;
            if (in == 0ULL) {
                break;
            }
            place *= (unsigned long long)b;
        }

        printf("Decimal: %llu\n", value);
    }

    return 0;
}
