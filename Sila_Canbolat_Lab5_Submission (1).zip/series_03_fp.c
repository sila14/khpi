#include <stdio.h>
#include <math.h>
#include <float.h>

/*
 * Lab 05_01 — Series Sums and Products
 * Variant 03 (odd) => floating-point version uses WHILE loop (per lab rule).
 *   S = sum_{k=0..m} (a^k * tan(x + 0.5k)) / (a + kx)
 */

int main(void)
{
    int m;
    double a, x;

    /* Input: m a x */
    if (scanf("%d %lf %lf", &m, &a, &x) != 3 || m < 0) {
        puts("Input error");
        return 1;
    }

    long double S = 0.0L;
    long double apow = 1.0L; /* a^0 */
    int k = 0;

    while (k <= m) {
        long double denom = (long double)a + (long double)k * (long double)x;

        if (denom == 0.0L) {
            puts("NaN");
            return 2;
        }

        long double angle = (long double)x + 0.5L * (long double)k;
        long double t = tanl(angle);

        if (!isfinite((double)t) || !isfinite((double)apow)) {
            puts("NaN");
            return 3;
        }

        long double term = (apow * t) / denom;
        S += term;

        apow *= (long double)a;
        ++k;
    }

    printf("%.10Lg\n", S);
    return 0;
}
