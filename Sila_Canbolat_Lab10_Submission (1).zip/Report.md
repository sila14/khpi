# Lab Work #10 — Files in C (Variant 3: Employees and Salaries)

**Student:** Sıla Canbolat (КН-925і.е, ННІ КНІТ)  
**Instructor:** Volodymyr Savchenko  
**Year:** 2025

## Objective
I did learn how to work with **text** and **binary** files in C: opening/closing streams, reading and writing records, searching, appending, and updating/deleting records. fileciteturn21file3L5-L8

## Variant
Variant **3**: *Employees and salaries* — each record stores **surname, department, position, salary**. I did implement search by department, salary increase in a department, and deletion of employees with zero salary. fileciteturn21file0L54-L55

## File formats
### Text file (`employees.txt`)
Afterwards I chose the format **one employee per line**:
```
Surname;Department;Position;Salary
```
Example:
```
Ivanenko;IT;Junior Dev;800.00
Petrenko;HR;Recruiter;0.00
```

### Binary file (`employees.bin`)
After that I stored the same information in a fixed-size `struct Employee` and wrote/read records with `fwrite/fread`. fileciteturn21file2L23-L33

## Implemented operations (both text and binary)
Finally I implemented a menu that calls these actions: create (overwrite), print all, search, raise salaries, delete zero salary, append records. fileciteturn21file0L11-L18

## Build and run
```bash
make
./build/app
```

## Test run examples (short)
I did test:
1) Create a file with 3 records (including one with salary 0).  
2) Print all records.  
3) Search department `IT`.  
4) Raise `IT` salaries by 10%.  
5) Delete zero-salary employees.  
6) Append 1 new record and print again.

## Debug session (example 10–20 lines)
```gdb
(gdb) break txt_raise_department
(gdb) run
Choose: 1
Choose: 4
(gdb) next
(gdb) print dept
$1 = "IT"
(gdb) print percent
$2 = 10
(gdb) continue
(gdb) break bin_delete_zero_salary
(gdb) continue
(gdb) next
(gdb) print deleted
$3 = 1
(gdb) continue
```

## References
- Lab Work #10 handout: file modes, operations, and variant table. fileciteturn21file3L13-L42
- Markdown for documentation (Report.md) style.
