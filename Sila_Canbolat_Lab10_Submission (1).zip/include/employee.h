#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <stdio.h>

#define MAX_SURNAME 48
#define MAX_DEPT    48
#define MAX_POS     48

typedef struct {
    char surname[MAX_SURNAME];
    char department[MAX_DEPT];
    char position[MAX_POS];
    double salary; /* UAH / USD / any currency - chosen by user */
} Employee;

/* Utility for printing one record in a readable form */
void employee_print(const Employee *e);

/* Utility for reading a record from keyboard (with validation) */
int employee_read(Employee *e);

#endif /* EMPLOYEE_H */
