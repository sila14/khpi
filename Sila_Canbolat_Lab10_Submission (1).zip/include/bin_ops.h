#ifndef BIN_OPS_H
#define BIN_OPS_H

#include "employee.h"

/* Binary file operations for Variant 3: Employees and salaries */
int bin_create(const char *path);
int bin_print_all(const char *path);
int bin_search_by_department(const char *path);
int bin_raise_department(const char *path);
int bin_delete_zero_salary(const char *path);
int bin_append(const char *path);

#endif /* BIN_OPS_H */
