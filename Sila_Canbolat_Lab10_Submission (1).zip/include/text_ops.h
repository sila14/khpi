#ifndef TEXT_OPS_H
#define TEXT_OPS_H

#include "employee.h"

/* Text file operations for Variant 3: Employees and salaries */
int txt_create(const char *path);
int txt_print_all(const char *path);
int txt_search_by_department(const char *path);
int txt_raise_department(const char *path);
int txt_delete_zero_salary(const char *path);
int txt_append(const char *path);

#endif /* TEXT_OPS_H */
