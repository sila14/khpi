/*
 * Lab Work #10: Files in C (Variant 3 — Employees and salaries)
 * Student: Sıla Canbolat (КН-925і.е, ННІ КНІТ)
 *
 * This project demonstrates text and binary file operations:
 * create, print, search, raise salaries in a department, delete zero-salary employees, append records.
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#include "employee.h"
#include "text_ops.h"
#include "bin_ops.h"

static void trim_newline(char *s) {
    if (!s) return;
    size_t n = strlen(s);
    if (n && s[n-1] == '\n') s[n-1] = '\0';
}

static void flush_stdin(void) {
    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF) { }
}

static int read_line(const char *prompt, char *buf, size_t cap) {
    if (!buf || cap == 0) return 0;
    printf("%s", prompt);
    if (!fgets(buf, (int)cap, stdin)) return 0;
    trim_newline(buf);
    return 1;
}

static int read_int(const char *prompt, int *out) {
    if (!out) return 0;
    printf("%s", prompt);
    if (scanf("%d", out) != 1) {
        flush_stdin();
        return 0;
    }
    flush_stdin();
    return 1;
}

static int read_double(const char *prompt, double *out) {
    if (!out) return 0;
    printf("%s", prompt);
    if (scanf("%lf", out) != 1) {
        flush_stdin();
        return 0;
    }
    flush_stdin();
    return 1;
}

static int is_blank(const char *s) {
    if (!s) return 1;
    while (*s) {
        if (!isspace((unsigned char)*s)) return 0;
        ++s;
    }
    return 1;
}

void employee_print(const Employee *e) {
    if (!e) return;
    printf("%-16s | %-14s | %-14s | %10.2f\n",
           e->surname, e->department, e->position, e->salary);
}

int employee_read(Employee *e) {
    if (!e) return 0;
    char buf[128];

    if (!read_line("Surname: ", buf, sizeof(buf)) || is_blank(buf)) return 0;
    strncpy(e->surname, buf, MAX_SURNAME - 1); e->surname[MAX_SURNAME - 1] = '\0';

    if (!read_line("Department: ", buf, sizeof(buf)) || is_blank(buf)) return 0;
    strncpy(e->department, buf, MAX_DEPT - 1); e->department[MAX_DEPT - 1] = '\0';

    if (!read_line("Position: ", buf, sizeof(buf)) || is_blank(buf)) return 0;
    strncpy(e->position, buf, MAX_POS - 1); e->position[MAX_POS - 1] = '\0';

    double sal = 0.0;
    if (!read_double("Salary (>=0): ", &sal)) return 0;
    if (sal < 0.0) return 0;
    e->salary = sal;

    return 1;
}

/* Export small helpers for modules */
int util_read_int(const char *prompt, int *out) { return read_int(prompt, out); }
int util_read_double(const char *prompt, double *out) { return read_double(prompt, out); }
int util_read_line(const char *prompt, char *buf, size_t cap) { return read_line(prompt, buf, cap); }
int util_is_blank(const char *s) { return is_blank(s); }

static void menu_text(const char *path) {
    int choice = -1;
    while (choice != 0) {
        printf("\n=== TEXT FILE MENU (%s) ===\n", path);
        printf("1) Create file (overwrite)\n");
        printf("2) Print all records\n");
        printf("3) Search by department\n");
        printf("4) Raise salaries in department\n");
        printf("5) Delete employees with zero salary\n");
        printf("6) Append new records\n");
        printf("0) Back\n");
        if (!read_int("Choose: ", &choice)) {
            printf("Invalid input.\n");
            continue;
        }
        switch (choice) {
            case 1: txt_create(path); break;
            case 2: txt_print_all(path); break;
            case 3: txt_search_by_department(path); break;
            case 4: txt_raise_department(path); break;
            case 5: txt_delete_zero_salary(path); break;
            case 6: txt_append(path); break;
            case 0: break;
            default: printf("Unknown option.\n"); break;
        }
    }
}

static void menu_bin(const char *path) {
    int choice = -1;
    while (choice != 0) {
        printf("\n=== BINARY FILE MENU (%s) ===\n", path);
        printf("1) Create file (overwrite)\n");
        printf("2) Print all records\n");
        printf("3) Search by department\n");
        printf("4) Raise salaries in department\n");
        printf("5) Delete employees with zero salary\n");
        printf("6) Append new records\n");
        printf("0) Back\n");
        if (!read_int("Choose: ", &choice)) {
            printf("Invalid input.\n");
            continue;
        }
        switch (choice) {
            case 1: bin_create(path); break;
            case 2: bin_print_all(path); break;
            case 3: bin_search_by_department(path); break;
            case 4: bin_raise_department(path); break;
            case 5: bin_delete_zero_salary(path); break;
            case 6: bin_append(path); break;
            case 0: break;
            default: printf("Unknown option.\n"); break;
        }
    }
}

int main(void) {
    const char *TXT_PATH = "employees.txt";
    const char *BIN_PATH = "employees.bin";

    int choice = -1;
    while (choice != 0) {
        printf("\n========== LAB 10 (VARIANT 3) ==========\n");
        printf("1) Work with TEXT file\n");
        printf("2) Work with BINARY file\n");
        printf("0) Exit\n");

        if (!read_int("Choose: ", &choice)) {
            printf("Invalid input.\n");
            continue;
        }

        if (choice == 1) menu_text(TXT_PATH);
        else if (choice == 2) menu_bin(BIN_PATH);
        else if (choice == 0) printf("Bye!\n");
        else printf("Unknown option.\n");
    }

    return 0;
}
