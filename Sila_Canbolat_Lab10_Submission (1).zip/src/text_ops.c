#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "text_ops.h"

/* Utilities from main.c */
int util_read_int(const char *prompt, int *out);
int util_read_double(const char *prompt, double *out);
int util_read_line(const char *prompt, char *buf, size_t cap);
int util_is_blank(const char *s);

static int read_record(FILE *f, Employee *e) {
    /* Format: surname;department;position;salary\n */
    char line[256];
    if (!fgets(line, sizeof(line), f)) return 0;

    char *p = strchr(line, '\n');
    if (p) *p = '\0';

    char *surname = strtok(line, ";");
    char *dept    = strtok(NULL, ";");
    char *pos     = strtok(NULL, ";");
    char *sal_s   = strtok(NULL, ";");

    if (!surname || !dept || !pos || !sal_s) return 0;

    strncpy(e->surname, surname, MAX_SURNAME - 1); e->surname[MAX_SURNAME - 1] = '\0';
    strncpy(e->department, dept, MAX_DEPT - 1); e->department[MAX_DEPT - 1] = '\0';
    strncpy(e->position, pos, MAX_POS - 1); e->position[MAX_POS - 1] = '\0';
    e->salary = atof(sal_s);

    return 1;
}

static void write_record(FILE *f, const Employee *e) {
    fprintf(f, "%s;%s;%s;%.2f\n", e->surname, e->department, e->position, e->salary);
}

int txt_create(const char *path) {
    int n = 0;
    if (!util_read_int("How many employees to write? ", &n) || n < 0) {
        printf("ERROR: invalid count.\n");
        return 0;
    }

    FILE *f = fopen(path, "w");
    if (!f) { perror("fopen"); return 0; }

    for (int i = 0; i < n; ++i) {
        printf("\nRecord #%d\n", i + 1);
        Employee e;
        if (!employee_read(&e)) {
            printf("ERROR: invalid record. Try again.\n");
            --i;
            continue;
        }
        write_record(f, &e);
    }

    fclose(f);
    printf("OK: file created.\n");
    return 1;
}

int txt_print_all(const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) { perror("fopen"); return 0; }

    printf("\nSURNAME           | DEPARTMENT      | POSITION        |     SALARY\n");
    printf("-------------------------------------------------------------------\n");
    Employee e;
    int count = 0;
    while (read_record(f, &e)) {
        employee_print(&e);
        count++;
    }
    fclose(f);
    printf("-------------------------------------------------------------------\n");
    printf("Total: %d\n", count);
    return 1;
}

int txt_search_by_department(const char *path) {
    char dept[MAX_DEPT];
    if (!util_read_line("Department to search: ", dept, sizeof(dept)) || util_is_blank(dept)) {
        printf("ERROR: empty department.\n");
        return 0;
    }

    FILE *f = fopen(path, "r");
    if (!f) { perror("fopen"); return 0; }

    int found = 0;
    Employee e;
    while (read_record(f, &e)) {
        if (strcmp(e.department, dept) == 0) {
            if (!found) {
                printf("\nMatches:\n");
                printf("SURNAME           | DEPARTMENT      | POSITION        |     SALARY\n");
                printf("-------------------------------------------------------------------\n");
            }
            employee_print(&e);
            found++;
        }
    }
    fclose(f);

    if (!found) printf("No employees found for department '%s'.\n", dept);
    else printf("-------------------------------------------------------------------\nFound: %d\n", found);
    return 1;
}

int txt_raise_department(const char *path) {
    char dept[MAX_DEPT];
    if (!util_read_line("Department to raise: ", dept, sizeof(dept)) || util_is_blank(dept)) {
        printf("ERROR: empty department.\n");
        return 0;
    }
    double percent = 0.0;
    if (!util_read_double("Percent increase (e.g., 10 for +10%): ", &percent)) {
        printf("ERROR: invalid percent.\n");
        return 0;
    }

    FILE *fin = fopen(path, "r");
    if (!fin) { perror("fopen"); return 0; }

    const char *tmp = "employees_tmp.txt";
    FILE *fout = fopen(tmp, "w");
    if (!fout) { perror("fopen"); fclose(fin); return 0; }

    int changed = 0;
    Employee e;
    while (read_record(fin, &e)) {
        if (strcmp(e.department, dept) == 0) {
            e.salary = e.salary * (1.0 + percent / 100.0);
            changed++;
        }
        write_record(fout, &e);
    }

    fclose(fin);
    fclose(fout);

    remove(path);
    rename(tmp, path);

    printf("OK: raised salaries for %d employee(s) in '%s'.\n", changed, dept);
    return 1;
}

int txt_delete_zero_salary(const char *path) {
    FILE *fin = fopen(path, "r");
    if (!fin) { perror("fopen"); return 0; }

    const char *tmp = "employees_tmp.txt";
    FILE *fout = fopen(tmp, "w");
    if (!fout) { perror("fopen"); fclose(fin); return 0; }

    int deleted = 0;
    Employee e;
    while (read_record(fin, &e)) {
        if (e.salary == 0.0) { deleted++; continue; }
        write_record(fout, &e);
    }

    fclose(fin);
    fclose(fout);

    remove(path);
    rename(tmp, path);

    printf("OK: deleted %d employee(s) with zero salary.\n", deleted);
    return 1;
}

int txt_append(const char *path) {
    int n = 0;
    if (!util_read_int("How many records to append? ", &n) || n < 0) {
        printf("ERROR: invalid count.\n");
        return 0;
    }

    FILE *f = fopen(path, "a");
    if (!f) { perror("fopen"); return 0; }

    for (int i = 0; i < n; ++i) {
        printf("\nNew record #%d\n", i + 1);
        Employee e;
        if (!employee_read(&e)) {
            printf("ERROR: invalid record. Try again.\n");
            --i;
            continue;
        }
        write_record(f, &e);
    }

    fclose(f);
    printf("OK: appended %d record(s).\n", n);
    return 1;
}
