#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "bin_ops.h"

/* Utilities from main.c */
int util_read_int(const char *prompt, int *out);
int util_read_double(const char *prompt, double *out);
int util_read_line(const char *prompt, char *buf, size_t cap);
int util_is_blank(const char *s);

static int write_all(FILE *f, const Employee *arr, int n) {
    size_t wrote = fwrite(arr, sizeof(Employee), (size_t)n, f);
    return (wrote == (size_t)n);
}

static int read_one(FILE *f, Employee *e) {
    return (fread(e, sizeof(Employee), 1, f) == 1);
}

int bin_create(const char *path) {
    int n = 0;
    if (!util_read_int("How many employees to write? ", &n) || n < 0) {
        printf("ERROR: invalid count.\n");
        return 0;
    }

    FILE *f = fopen(path, "wb");
    if (!f) { perror("fopen"); return 0; }

    for (int i = 0; i < n; ++i) {
        printf("\nRecord #%d\n", i + 1);
        Employee e;
        if (!employee_read(&e)) {
            printf("ERROR: invalid record. Try again.\n");
            --i;
            continue;
        }
        if (fwrite(&e, sizeof(Employee), 1, f) != 1) {
            perror("fwrite");
            fclose(f);
            return 0;
        }
    }

    fclose(f);
    printf("OK: binary file created.\n");
    return 1;
}

int bin_print_all(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) { perror("fopen"); return 0; }

    printf("\nSURNAME           | DEPARTMENT      | POSITION        |     SALARY\n");
    printf("-------------------------------------------------------------------\n");

    Employee e;
    int count = 0;
    while (read_one(f, &e)) {
        employee_print(&e);
        count++;
    }
    fclose(f);
    printf("-------------------------------------------------------------------\n");
    printf("Total: %d\n", count);
    return 1;
}

int bin_search_by_department(const char *path) {
    char dept[MAX_DEPT];
    if (!util_read_line("Department to search: ", dept, sizeof(dept)) || util_is_blank(dept)) {
        printf("ERROR: empty department.\n");
        return 0;
    }

    FILE *f = fopen(path, "rb");
    if (!f) { perror("fopen"); return 0; }

    int found = 0;
    Employee e;
    while (read_one(f, &e)) {
        if (strcmp(e.department, dept) == 0) {
            if (!found) {
                printf("\nMatches:\n");
                printf("SURNAME           | DEPARTMENT      | POSITION        |     SALARY\n");
                printf("-------------------------------------------------------------------\n");
            }
            employee_print(&e);
            found++;
        }
    }
    fclose(f);

    if (!found) printf("No employees found for department '%s'.\n", dept);
    else printf("-------------------------------------------------------------------\nFound: %d\n", found);
    return 1;
}

int bin_raise_department(const char *path) {
    char dept[MAX_DEPT];
    if (!util_read_line("Department to raise: ", dept, sizeof(dept)) || util_is_blank(dept)) {
        printf("ERROR: empty department.\n");
        return 0;
    }
    double percent = 0.0;
    if (!util_read_double("Percent increase (e.g., 10 for +10%): ", &percent)) {
        printf("ERROR: invalid percent.\n");
        return 0;
    }

    FILE *fin = fopen(path, "rb");
    if (!fin) { perror("fopen"); return 0; }

    const char *tmp = "employees_tmp.bin";
    FILE *fout = fopen(tmp, "wb");
    if (!fout) { perror("fopen"); fclose(fin); return 0; }

    int changed = 0;
    Employee e;
    while (read_one(fin, &e)) {
        if (strcmp(e.department, dept) == 0) {
            e.salary = e.salary * (1.0 + percent / 100.0);
            changed++;
        }
        if (fwrite(&e, sizeof(Employee), 1, fout) != 1) {
            perror("fwrite");
            fclose(fin); fclose(fout);
            return 0;
        }
    }

    fclose(fin);
    fclose(fout);

    remove(path);
    rename(tmp, path);

    printf("OK: raised salaries for %d employee(s) in '%s'.\n", changed, dept);
    return 1;
}

int bin_delete_zero_salary(const char *path) {
    FILE *fin = fopen(path, "rb");
    if (!fin) { perror("fopen"); return 0; }

    const char *tmp = "employees_tmp.bin";
    FILE *fout = fopen(tmp, "wb");
    if (!fout) { perror("fopen"); fclose(fin); return 0; }

    int deleted = 0;
    Employee e;
    while (read_one(fin, &e)) {
        if (e.salary == 0.0) { deleted++; continue; }
        if (fwrite(&e, sizeof(Employee), 1, fout) != 1) {
            perror("fwrite");
            fclose(fin); fclose(fout);
            return 0;
        }
    }

    fclose(fin);
    fclose(fout);

    remove(path);
    rename(tmp, path);

    printf("OK: deleted %d employee(s) with zero salary.\n", deleted);
    return 1;
}

int bin_append(const char *path) {
    int n = 0;
    if (!util_read_int("How many records to append? ", &n) || n < 0) {
        printf("ERROR: invalid count.\n");
        return 0;
    }

    FILE *f = fopen(path, "ab");
    if (!f) { perror("fopen"); return 0; }

    for (int i = 0; i < n; ++i) {
        printf("\nNew record #%d\n", i + 1);
        Employee e;
        if (!employee_read(&e)) {
            printf("ERROR: invalid record. Try again.\n");
            --i;
            continue;
        }
        if (fwrite(&e, sizeof(Employee), 1, f) != 1) {
            perror("fwrite");
            fclose(f);
            return 0;
        }
    }

    fclose(f);
    printf("OK: appended %d record(s).\n", n);
    return 1;
}
